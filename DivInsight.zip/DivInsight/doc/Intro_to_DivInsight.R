## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(DivInsight)

## -----------------------------------------------------------------------------
#clusterised_Colombia <- clusterise_sites(dataframe = Colombia, cluster_min_length = 30)

