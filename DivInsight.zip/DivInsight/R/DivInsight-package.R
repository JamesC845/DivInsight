#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom graphics abline
#' @importFrom stats as.dist
#' @importFrom stats cutree
#' @importFrom stats hclust
#' @importFrom stats lm
## usethis namespace: end
NULL
